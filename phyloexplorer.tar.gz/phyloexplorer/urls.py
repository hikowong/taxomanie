from django.conf import settings
from django.conf.urls.defaults import *

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

if settings.DEBUG:
    urlpatterns = patterns('',
    (r'^site_media/(?P<path>.*)$', 'django.views.static.serve',
      {'document_root': '/home/taxomanie/phyloexplorer/templates'}),
    )
else:
    urlpatterns = patterns('', () )

urlpatterns += patterns('',
    # Example:
    #(r'^taxomanie/', include('taxomanie.phylocore.urls')),

    (r'^get_img_url/(?P<taxon>.*)$', 'phyloexplorer.views.get_img_url'),
    (r'^recreate_collection$', 'phyloexplorer.views.recreate_collection'),
    (r'^statistics$', 'phyloexplorer.views.statistics'),
    (r'^browse$', 'phyloexplorer.views.browse'),
    (r'^help$', 'phyloexplorer.views.help'),
    (r'^about$', 'phyloexplorer.views.about'),
    (r'^', 'phyloexplorer.views.index'),

    #(r'^articles/(\d{4})/$', 'news.views.year_archive'),
    #(r'^articles/(\d{4})/(\d{2})/$', 'news.views.month_archive'),
    #(r'^articles/(\d{4})/(\d{2})/(\d+)/$', 'news.views.article_detail'),

    # Uncomment the admin/doc line below and add 'django.contrib.admindocs' 
    # to INSTALLED_APPS to enable admin documentation:
    # (r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    # (r'^admin/(.*)', admin.site.root),
)


