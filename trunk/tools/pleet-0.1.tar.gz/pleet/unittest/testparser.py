#!/usr/bin/env python
#-*- coding: utf-8 -*-

## Copyright © 2007 Nicolas Clairon, n.namlook@gmail.com

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

import sys
sys.path.insert( 0, ".." )

import unittest
from pleet.pleet import Pleet
from pleet.pleet import RenderNonExposedError
from pleet.pleet import RenderPourcentError

# TODO: test on convertion


class testParser( unittest.TestCase ):
    """ Class test of Parser  """

    def test_goodPythonLine( self ):
        """ Test the evaluation of python code line """
        tpl = "3+4 font <%$ 3+4 %>"
        result = "3+4 font 7\n"

        parser = Pleet( tpl )
        template = parser._Pleet__evalPythonCode( tpl )  
        self.assertEquals( template, result,
          msg='should eval a python code line\n%s\n----------------\n%s' % (
            template, result ) )

    def test_goodPythonBlock( self ):
        tpl = """block: 3+4 font
<%
print 3+4
%>
""" 
        result = """block: 3+4 font\n7\n"""
        parser = Pleet( tpl )
        template = parser._Pleet__evalPythonCode( tpl )  
        self.assertEquals( template, result,
          msg='should eval a python code block\n%s\n----------------\n%s' % (
            template, result ) )

    def test_badPythonBlock( self ):
        tpl = """je m'appelle
<% print "Nico"
%>"""
        result = """je m'appelle
<% print "Nico"
%>"""
        parser = Pleet( tpl )
        template = parser._Pleet__evalPythonCode( tpl )  
        self.assertEquals( template, result,
          msg='A bad python block must not eval' )

    def test_goodCommentBlock( self ):
        tpl = """un essai
<%#
print "\%>"
#%>
"""
        result ="""un essai\n"""
        parser = Pleet( tpl )
        template = parser._Pleet__evalPythonCode( tpl )  
        self.assertEquals( template, result,
          msg='should ommit commented block \n%s\n----------------\n%s' % (
            template, result ) )

#    def test_goodCommentPythonine1( self ):
#        tpl = """un essai
#<%# print "\%>" %>
#"""
#        result ="""un essai
#"""
#        parser = Pleet( tpl )
#        template = parser._Pleet__evalPythonCode( tpl )  
#        self.assertEquals( template, result,
#          msg='should ommit commented line (1)\n%s\n----------------\n%s' % (
#            template, result ) )
#
#    def test_goodCommentPythonLiner2( self ):
#        tpl = """un essai
#<%#print "\%>"%>
#"""
#        result ="""un essai
#"""
#        parser = Pleet( tpl )
#        template = parser._Pleet__evalPythonCode( tpl )  
#        self.assertEquals( template, result,
#          msg='should ommit commented line (2)\n%s\n----------------\n%s' % (
#            template, result ) )
#

    def test_ifStatementTrue( self ):
        tpl = """bla
<%
if True:
%>
    <%|%>
    Coucou
"""
        result = """bla\n    Coucou\n"""
        parser = Pleet( tpl )
        template = parser.render()
        self.assertEquals( template, result,
          msg='should eval the if statement \n%s\n----------------\n%s' % (
            template, result ) )

    def test__ifStatementFalse( self ):
        tpl = """bla
<%
if 0:
%>
    <%|%>
    Coucou
<%|%>
coucou
"""
        result = """bla
coucou
"""
        parser = Pleet( tpl )
        template = parser.render()
        self.assertEquals( template, result,
          msg='should eval the if statement \n%s\n----------------\n%s' % (
            template, result ) )

    def test__elseStatement( self ):
        tpl = """
<%
if 0:
%>
    <%|%>
    Coucou
<%
else:
%>
    <%|%>
    Salut
<%|%>
coucou
"""
        result = """    Salut
coucou
"""
        parser = Pleet( tpl )
        template = parser.render()
        self.assertEquals( template, result,
          msg='should eval the if statement \n%s\n----------------\n%s' % (
            template, result ) )

    def test__elifStatement( self ):
        tpl = """
<%
if 0:
%>
    <%|%>
    Coucou
<%
elif 1:
%>
    <%|%>
    Salut
<%|%>
"""
        result = """    Salut
"""
        parser = Pleet( tpl )
        template = parser.render()
        self.assertEquals( template, result,
          msg='should eval the elif statement \n%s\n----------------\n%s' % (
            template, result ) )

    def test__elifStatementi_withElse( self ):
        tpl = """
<%
if 0:
%>
    <%|%>
    Coucou
<%
elif False:
%>
    <%|%>
    Salut
<%
else:
%>
    <%|%>
    Hello
"""
        result = """    Hello
"""
        parser = Pleet( tpl )
        template = parser.render()
        self.assertEquals( template, result,
          msg='should eval the elif statement with else statement\n%s\n----------------\n%s' % (
            template, result ) )


    def test_exposeVariableBlock( self ):
        tpl = """
<%
name = "Nicolas"
%>
Hi <%$ name %>!"""

        result = """Hi Nicolas!\n"""
        parser = Pleet( tpl )
        template = parser.render()
        self.assertEquals( template, result,
          msg='should eval an exposed variable \n%s\n----------------\n%s' % (
            template, result ) )

#    def test_exposeVariableLine( self ):
#        tpl = """<% name = "Nicolas" %>Hi %(name)s !"""
#
#        result = """Hi Nicolas !"""
#        parser = Pleet( tpl )
#        template = parser.render()
#        self.assertEquals( template, result,
#          msg='should eval an exposed variable \n%s\n----------------\n%s' % (
#            template, result ) )

    def test__forStatement( self ):
        tpl = """bla
<%
for i in range( 5 ):
%>
    <%|%>
    <%$ i %>) Coucou
"""
        result = """bla
    0) Coucou
    1) Coucou
    2) Coucou
    3) Coucou
    4) Coucou
"""
        parser = Pleet( tpl )
        template = parser.render()
        self.assertEquals( template, result,
          msg='should eval the for statement \n%s\n----------------\n%s' % (
            template, result ) )

    def test_includeTemplate( self ):
        tpl = """I say <%@ tpl.html %> That's all !"""


        result = """I say <b>Hello World</b> That's all !"""
        parser = Pleet( tpl )
        template = parser.render()
        self.assertEquals( template, result,
          msg='should include a template \n%s\n----------------\n%s' % (
            template, result ) )

    def test_varStatement( self ):
        tpl = """
<%
personne = "Me"
%>
Hello <%$ personne %> !
"""


        result = """Hello Me !
"""
        parser = Pleet( tpl )
        template = parser.render()
        self.assertEquals( template, result,
          msg='should eval var statement \n%s\n----------------\n%s' % (
            template, result ) )


    def test_varStatement_withMethod( self ):
        tpl = """
<%
personne = "Me bla"
%>
Hello <%$ personne.split() %> !"""


        result = """Hello ['Me', 'bla'] !\n"""
        parser = Pleet( tpl )
        template = parser.render()
        open( "/tmp/template", "w" ).write( template )
        open( "/tmp/result", "w" ).write( result )
        self.assertEquals( template, result,
          msg='should eval var statement \n%s\n----------------\n%s' % (
            template, result ) )



if __name__ == '__main__':
    unittest.main()

