#!/usr/bin/env python
#-*- coding: utf-8 -*-

import pleet

template = """bouh

<%
from mx import DateTime
print 3 + 4
print DateTime.now()
print "bla"
%>
bldlkjsdfkj sdkljf sdklj fsdbla
<% print "coucou" %>
bdslkfdsj lksj fs
<% print 3+4
print "coucou"
%>
"""
template1=\
"""bla
<%= if 1 %>

Coucou 
<%= endif %>
bla
"""


evalpython = pleet.parser.EvalPythonCode()
evalpython.debug = True
print evalpython.render( template )
