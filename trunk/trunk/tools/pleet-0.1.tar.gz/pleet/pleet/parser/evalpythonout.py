#-*- coding: utf-8 -*-
## Copyright © 2007 Nicolas Clairon <n.namlook@gmail.com >

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#from emeralOut import EmeralOut

from passoa.passoaout import PassoaOut
import sys

class EvalPythonError( Exception ): pass

class Output:
    def __init__( self ):
        self.__render = ''
    def write(self, str):
        self.__render = self.__render + str
    def get( self ):
        render = self.__render
        self.__render = ''
        return render


class EvalPythonOut( PassoaOut ):
    """ Wiki of Trac object """
    # Exposed objects dictionnary
    exposed = {}
    # This dictionnary is used to keep all locals variables in the templates
    locals = {} 

    def __treatExposedObject( self ):
        # XXX Only for depoZ compatibility ( a supprimer )
        """ Put into the namespace all exposed objects """
        for name, value in self.exposed.iteritems():
            setattr( self, name , value )

    def __execute( self, code ):
        """
        This methode is executed each time we want to eval python code
        """
        self.__treatExposedObject()
        locals().update( self.locals )
        self._output = Output()
        self.__prior, sys.stdout = sys.stdout, self._output
        try:
            exec code
        except Exception, e:
            sys.stdout = self.__prior
            raise EvalPythonError, "%s\ncan't execute python code :\n%s" % (
              e, code )
        sys.stdout = self.__prior
        self.locals.update( locals() )
        return self._output.get()

    def code_block( self, (tag,start,stop,subtags), buffer ):
        """ return the result of evalutation of python code block"""
        return self.__execute( buffer[start:stop] ).strip()

    def code_line( self, (tag,start,stop,subtags), buffer ):
        """ return the result of evalutation of python code line """
        return self.__execute( buffer[start:stop].strip() ).strip()
    
    def code_comment_block( self, (tag,start,stop,subtags), buffer ):
        """ pass all comments """
        return ""

    def code_comment_line( self, (tag,start,stop,subtags), buffer ):
        """ pass all comments """
        return ""

    def if_statement( self, (tag,start,stop,subtags), buffer ):
        """ 
        eval the condition and display the if_block if the condition is
        True
        """
        conditions_list = []
        for tag in subtags:
            if tag[0] == "if_tag":
                condition, if_block = None, None
                for item in tag[3]:
                    if item[0] == "if_condition":
                        condition =  buffer[item[1]:item[2]]
                    if item[0] == "if_block":
                        if_block = buffer[item[1]:item[2]]#.strip()
                    if condition and if_block:
                        conditions_list.append( ( condition, if_block ) )
            if tag[0] == "elif_tag":
                condition, if_block = None, None
                for item in tag[3]:
                    if item[0] == "if_condition":
                        condition = buffer[item[1]:item[2]]
                    if item[0] == "if_block":
                        if_block = buffer[item[1]:item[2]].strip()
                    if condition and if_block:
                        conditions_list.append( ( condition, if_block ) )
            if tag[0] == "else_tag":
                else_block = None
                else_block = buffer[tag[3][0][1]:tag[3][0][2]].strip()
                conditions_list.append( ( "True", else_block ) )
        locals().update( self.locals )
        for condition, block in conditions_list:
            if not ( condition.strip() and block ):
                raise ValueError, "Bad if statement" 
            if eval( condition ):
                return self.render( block )
        return ""

    def for_statement( self, (tag,start,stop,subtags), buffer ):
        """
        Eval the for statement and expose the value
        """
        res = ""
        for tag in subtags:
            if tag[0] == "for_var":
                var = buffer[tag[1]:tag[2]]
            if tag[0] == "for_container":
                locals().update( self.locals )
                container = eval(buffer[tag[1]:tag[2]])
            if tag[0] == "for_block":
                block = buffer[tag[1]:tag[2]]
        for i in container:
            self.locals[var.strip()] = i
            try:
                block = block.replace( "\%", "#~&~#" )
                res += self.render( block ) % self.locals 
            except Exception, e:
                raise EvalPythonError, "%s in block %s" % (e, block)
        return res
        
    def include_statement( self, (tag,start,stop,subtags), buffer ):
        """
        Include the name of the template wrote beetween <%! %>

        It will use the finder methode to find templates
        """
        for tag in subtags:
            if tag[0] == "template_name":
                return self.finder( buffer[tag[1]:tag[2]].strip() ).strip()
        return ""

    def var_statement( self, (tag,start,stop,subtags), buffer ):
        """
        Will eval the variable and display the result

        <%$ var %> is the same than <% print var %> 
        """
        var = buffer[subtags[0][1]:subtags[0][2]].strip()
#        my_locals = {}
#        my_locals.update( locals() )
        locals().update( self.locals )
        res = str( eval( var ) )
#        locals().clear()
#        locals().update( my_locals )
        return res


    def other( self, (tag,start,stop,subtags), buffer ):
        return buffer[start:stop]

    def linereturn( self, (tag,start,stop,subtags), buffer ):
        return "\n"


