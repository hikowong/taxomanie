#!/usr/bin/env python
#-*- coding: utf-8 -*-

#from passoa.engine import Engine
#from evalpythonin import EvalPythonIn
#from evalpythonout import EvalPythonOut

from parser import Parser

class EvalPythonCode( Parser ):
#class EvalPythonCode( Engine, EvalPythonIn, EvalPythonOut ):
     def __init__( self, exposed_objects ):
        super( EvalPythonCode, self ).__init__()
        self._locals = exposed_objects

class Output:
    def __init__( self ):
        self.__render = ''
    def write(self, str):
        self.__render = self.__render + str
    def get( self ):
        render = self.__render
        self.__render = ''
        return render
