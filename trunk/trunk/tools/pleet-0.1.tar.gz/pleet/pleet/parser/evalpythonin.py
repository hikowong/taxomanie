#-*- coding: utf-8 -*-
## Copyright © 2007 Nicolas Clairon <n.namlook@gmail.com >

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

from passoa.passoain import PassoaIn

class EvalPythonIn( PassoaIn ):
    """ evalpython """
    grammar = r"""
root := ( struct )+

space := [ \t]
linereturn := ( "\r\n" / [\n] )

<hollow_linereturn> := linereturn
<hollow_space> := space

>struct< := ( 
#             linereturn / 
              if_statement /
              for_statement /
              include_statement /
              var_statement /
              code_python_comment_block /
              code_python_comment_line /
              code_python_block /
              code_python_line /
              other /
              markup
            )
              
>markup< := ( 
              mark_if_statement /
              mark_elif_statement /
              mark_else_statement /
              mark_for_statement /
              mark_include_statement /
              mark_var_statement /
              mark_code_python_line_open /
              mark_code_python_line_close /
              mark_code_python_block_open /
              mark_code_python_comment_block_open /
              mark_code_python_comment_line_open /
              mark_code_python_block_close /
              mark_endif_statement /
              mark_endfor_statement
            )

>mark_code_python_comment_block_open< := hollow_linereturn?, "<%#", hollow_linereturn+
>mark_code_python_comment_line_open< := "<%#"
>mark_code_python_line_open< := "<%"
>mark_code_python_line_close< := "%>"
>mark_code_python_block_open< := hollow_linereturn?, "<%", hollow_linereturn+
>mark_code_python_block_close< := "%>", hollow_space*, hollow_linereturn

code_comment_block := -mark_code_python_block_close+
code_comment_line := -(mark_code_python_line_close/ linereturn)+
code_line := -(mark_code_python_line_close/ linereturn)+
code_block := -mark_code_python_block_close+

>code_python_block< := mark_code_python_block_open, code_block, mark_code_python_block_close
>code_python_comment_block< := mark_code_python_comment_block_open, code_comment_block, mark_code_python_block_close
>code_python_comment_line< := mark_code_python_comment_line_open, code_comment_line, mark_code_python_line_close, hollow_linereturn 
>code_python_line< := mark_code_python_line_open, code_line, mark_code_python_line_close

if_statement := ( if_tag / elif_tag / else_tag )+, mark_endif_statement
if_tag := mark_if_statement, if_condition, mark_code_python_line_close, if_block
if_condition := -mark_code_python_line_close+
if_block := -(mark_elif_statement/mark_else_statement/mark_endif_statement)+
>mark_if_statement< := hollow_linereturn?, "<%=", hollow_space*, "if", hollow_space*

elif_tag := mark_elif_statement, if_condition, mark_code_python_line_close, if_block
>mark_elif_statement< := hollow_linereturn?, "<%=", hollow_space*, "elif", hollow_space*

else_tag := mark_else_statement, mark_code_python_line_close, else_block
else_block := -mark_endif_statement+
>mark_else_statement< := "<%=", hollow_space*, "else", hollow_space*
>mark_endif_statement< := hollow_linereturn*, "<%=", hollow_space*, "endif", hollow_space*, mark_code_python_line_close

for_statement := mark_for_statement, for_var, "in", for_container, mark_code_python_line_close, for_block, mark_endfor_statement
>mark_for_statement< := "<%=", hollow_space*, "for", hollow_space*
for_var := -("in")+
for_container := -(mark_code_python_line_close)+
for_block := -mark_endfor_statement+
>mark_endfor_statement< := hollow_linereturn*, "<%=", hollow_space*, "endfor", hollow_space*, mark_code_python_line_close


var_statement := mark_var_statement, var_name, mark_code_python_line_close
>mark_var_statement< := "<%$", hollow_space*
var_name := -mark_code_python_line_close+


include_statement := mark_include_statement, template_name, mark_code_python_line_close
template_name := -mark_code_python_line_close+
>mark_include_statement< := hollow_linereturn?, "<%!", hollow_space*

other := -( 
           code_python_comment_block /
           code_python_comment_line /
           code_python_block /
           code_python_line /
           if_statement /
           for_statement /
           include_statement /
           var_statement
          )+
"""

