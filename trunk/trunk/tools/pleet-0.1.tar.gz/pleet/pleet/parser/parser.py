# -*- coding: utf-8 -*-
# $Id: parser.py 286 2007-11-08 15:29:06Z joel $
## Copyright © 2006 Joël Maïzi <joel.maizi@lirmm.fr>

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

import sys
import re
#from Tracer import Tracer

test = False

class Output( object ):
    def __init__( self ):
        self.__render = ''
    def write(self, str):
        self.__render = self.__render + str
    def get( self ):
        render = self.__render
        self.__render = ''
        return render or ''

class Parser( object ):
    #__metaclass__ = Tracer
    """
    Pour l'instant très sommaire.
    les marques <% et %> doivent être isolées en début de ligne
    l'indentation du code est reproduite telle quelle.
    les lignes de code, si elles sont troquées ne peuvent l'être que par
    un '\' en fin de ligne.
    """
    code_begin_mark = "<%"
    code_end_mark = "%>"
    comment_begin_mark = "<%#"
    comment_end_mark = "#%>"
    code_begin_inline_mark = r"<%\$"
    include_begin_mark = r"<%\("
    inline_code = re.compile( '%s.[^%s]*%s' % (
      code_begin_inline_mark, code_end_mark[0], code_end_mark ) )
    indent_mark = re.compile( r"<%\|" )
    indent_line = re.compile( r"\s*<%\|" )
    non_space = re.compile( r'\S' )

    def __init__( self, template = None, **kwarg ):
        self._output = Output()
        self._locals = {}
        self._template = template
        if template:
            self.__template_list = template.split( "\n" )
        else:
            self.__template_list = []
        self.__in_code = False
        self.__in_comment = False
        self.__indentation = 0
        self.__skip_next_indent = False

    def __execute( self, code ):
        """
        plus d'exécution ici. le parser se contente de générer le code
        compilé. à supprimer ???
        """
        if test:
            sys.stderr.write( "in>>> Parser.__execute()\n" )
        self.__prior, sys.stdout = sys.stdout, self._output
        locals().update( self._locals )
        #if True:
        try:
            if test:
                sys.stderr.write( "%s\n" % code )
            exec code
        #else:
        except ValueError, e:
            sys.stdout = self.__prior
            raise ValueError, "can't execute python code : %s\n%s" % (
              e, code )
        sys.stdout = self.__prior
        if test:
            sys.stderr.write( "out<<< Parser.__execute()\n" )
        return self._output.get()

    def __escapeLine( self, line ):
        line = line.replace( '\\', '\\\\' )
        line = line.replace( '"', '\\"' )
        return line

    def __printLine( self, line, _code = False, _return = True ):
        """
        @param line: la ligne à imprimer
        @param _code: s'il s'agit de code. Par défaut à False
        @param _return: si l'impression doit se faire avec un retour à la ligne
        par défaut à True
        @return: La ligne contenant le code nécessaire à l'affichage
        """
        if test:
            sys.stderr.write( "in>>> Parser.__printLine()\n" )
        if not _code:
            line = self.__escapeLine( line )
            line = '"' + line + '"'
            line = " " * self.__indentation + "print %s" % ( line )
        else:
            line = " " * self.__indentation + line
        if not _return and not _code:
            line += ","
        line += "\n"
        if test:
            sys.stderr.write( "out<<< Parser.__printLine( %s )\n" % line )
            sys.stderr.write( "indentation : %s\n" % self.__indentation )
        return line

    def __prepareInlineCode( self, line ):
        gauche = '"""' + "%s".join(
          re.split( self.inline_code, self.__escapeLine( line ) ) ) + '"""'
        droite = ", ".join(
          [ i[3:-2] for i in re.findall( self.inline_code, line ) ] )
        return "print %s %% ( %s )" % ( gauche, droite )

    def __printCodeLine( self, line ):
        """
        la mal nommée. génère la ligne de code python (   print "... )
        en tenant compte de l'indentation.
        """
        if re.match( self.indent_line, line ):
            # on ne fait que noter l'indentation
            self.__indentation = len( re.split( self.indent_mark, line )[0] )
            return ''
        if len( re.split( self.inline_code, line ) ) > 1:
            # si on a du code embarqué dans la ligne
            return self.__printLine(
              self.__prepareInlineCode( line ), _code = True )
        else:
            return self.__printLine( line )

    def __includeCode( self, template_name ):
        """
        on doit inclure le code de la template dont le nom est passé
        en argument. Pour l'instant le chargement est fait au niveau
        du module presentation. Dans l'optique ou le code des templates
        est précompilé pour le module présentation, c'est ici que les
        noms sont passés
        Ce sont les objets qui font la demande de génération du code
        précompilé ?
        """
        pass

    def __genCode( self ):
        """
        génère le code de la template pour exécution par __render
        la template a été "splitée" et se trouve dans self.__template_list
        """
        template_code = []
        self.num_line = 0
        for line in self.__template_list:
            self.num_line += 1
            if line == self.comment_begin_mark:
                self.__in_comment = True
                continue
            if self.__in_comment and line != self.comment_end_mark:
                continue
            if self.__in_comment and line == self.comment_end_mark:
                self.__in_comment = False
                continue
            if self.include_begin_mark:
                # gestion des inclusions
                pass
            if line == self.code_begin_mark:
                self.__in_code = True
                continue
            elif line == self.code_end_mark:
                self.__in_code = False
                continue
            else:
                if self.__in_code:
                    self.__indentation = len(
                      re.split( self.non_space, line )[0] )
                    template_code.append( line )
                else:
                    template_code.append( self.__printCodeLine( line ) )
        return "\n".join( template_code ) + "\n"

    def parse( self, template = None ):
        """
        méthode invoquée par presentation.post
        """
        if template:
            self._template = template.strip()
            self.__template_list = self._template.split( "\n" )
        template_code = self.__genCode()
        if test:
            return self.__execute( template_code )
        else:
            if True:
            #try:
                res = self.__execute( template_code )
                return res
            else:
            #except ValueError:
                sys.stderr.write( "ERR depoZ\n%s\n" % template_code )
                raise RuntimeError, "\ncheck template code\n"

    def genCode( self, template = None ):
        if template:
            self._template = template.strip()
            self.__template_list = self._template.split( "\n" )
        return self.__genCode()
