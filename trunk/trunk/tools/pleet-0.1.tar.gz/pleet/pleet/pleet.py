#!/usr/bin/env python
#-*- coding: utf-8 -*-
# $Id: $

from parser import EvalPythonCode
try:
    from passoa.parsers import get_parser
except:
    get_parser = None
#    import sys
#    sys.stderr.write( "Warning: Passoa not found, you won't be able to convert" )
from exceptions import Exception

class RenderError( Exception ): pass
class RenderNonExposedError( RenderError ):pass
class RenderPourcentError( RenderError ):pass
class RenderNoTemplateError( RenderError ):pass


class Pleet( object ):
    #TODO 
    """
    TODO:
        * Encoding
        * while loops
        * include (<%! mytemplate.html %>)
            - creer la methode finder( self )
            + la template ne doit pas etre interpretee
    """
    def __init__( self, template=None ):
        self.__template = template
        self.__parser = None
        self.__conversion = None
        self._debug = False
        self.__path = None
        self.exposed = {}

    def __getitem__( self, item ):
        return self.exposed[item]

    def __setitem__( self, item, value ):
        self.exposed[item] = value

    def setPath( self, path ):
        self.__path = path

    def getPath( self ):
        return self.__path

    def finder( self, template_name, path = "." ):
        """
        This method is used to find where templates are stocked (used
        by the <%! %> balises.

        This method must be overwrited to feed other needs 
        """
        if self.__path is None:
            self.__path = path
        return open( path+"/"+template_name ).read()

    def expose( self, value, name = None, conversion = None, force = False ):
        """
        @value (object): Value of the object to be exposed
        @name (string): Expose object as "name"
        @conversion (tuple): convert the object exposed ( ie : ( "wiki", "html" ) )
        """
        if conversion and get_parser:
            from_format, to_format = conversion
            value = get_parser( from_format, to_format ).render( str(value) )
        if not name:
            name = value.__class__.__name__
        self.exposed[name] = value

    def getTemplate( self ):
        return self.__template

    def setTemplate( self, template ):
        self.__template = template

    def setConversion( self, conversion  ):
        """
        Conversion must be a tuple of string ( from, to ): ('wiki', 'html' )
        """
        if conversion and get_parser:
            from_format, to_format = conversion
            self.__parser = get_parser( from_format, to_format )
        else:
            self.__parser = None
        self.__conversion = conversion

    def getConversion( self ):
        return self.__conversion

    def __evalPythonCode( self, template ):
        """
        replace python code by the result

        template = template.replace( "\%>", "-*-\%\>-*-" )
        evalpython = EvalPythonCode( self.exposed )
        evalpython.finder = self.finder
        if self._debug:
            evalpython.debug = True
        evalpython.exposed = self.exposed
        ### XXX The following is necessary if we dont want to melange locals and
        ###  exposed objects. if we comment this line, we won't be able to
        ### access all variables declared in the template via the %(name)s methode
        evalpython.locals = self.exposed
        # for k,v in self.exposed.iteritems():
        # evalpython.locals[k] = v
        return evalpython.render( template ).replace( "-*-\%\>-*-", "%>" )
        """
#        template = template.replace( "\%>", "-*-\%\>-*-" )
        evalpython = EvalPythonCode( self.exposed )
        evalpython.finder = self.finder
        if self._debug:
            evalpython.debug = True
        #evalpython.exposed = self.exposed
        ### XXX The following is necessary if we dont want to melange locals and
        ###  exposed objects. if we comment this line, we won't be able to
        ### access all variables declared in the template via the %(name)s methode
        #evalpython.locals = self.exposed
        # for k,v in self.exposed.iteritems():
        # evalpython.locals[k] = v
        return evalpython.parse( template )#.replace( "-*-\%\>-*-", "%>" )

    def render( self, convert = True ):
        """
        Eval python code
        If a conversion is specify and convert = True, then the template will
        be converted to the specifique format (set in conversion)
        """
        if not self.__template:
            raise RenderNoTemplateError, "You must specify a template"
        result =  self.__evalPythonCode( self.__template )
#        result = result.replace( "\%", "#~&~#" )
        """
        try:
            result = result % self
        except KeyError, e:
            raise RenderNonExposedError, "%s is not exposed" % e
        except TypeError, e:
            raise RenderPourcentError, "'%' must be escapted : '\%'"
        except ValueError, e:
            raise RenderPourcentError, \
              "'%' must be escapted : '\%'\nCheck if tags are well closed"
        """
#        result = result.replace( "#~&~#", "%" )
        if self.__conversion and convert and get_parser:
            result = self.__parser.render( result )
        return result

    def clear( self ):
        """ Clear all exposed objects """
        self.exposed = {}

    def isExposed( self, name ):
        """
        @name (string): name of the exposed object

        Return True if name exists (ie: an object is exposed under this name)
        """
        return self.exposed.has_key( name )

if __name__ == "__main__":
    tpl = \
"""= bonjour =
salut <%$ nom %> ca va ?
Voici la date <%$ date %>  """

    parser = Pleet( tpl )
    # exposition des objets
    parser["nom"] = "Nicolas"
    parser["date"] = "12/12/12"
    

    # affichage
    print "=======template========="
    print parser.render()
    print "=====template html======"
    # conversion de la template en html
    parser.setConversion( ( "tracwiki", "html" ) )
    print parser.render()
    print "========================"


    tpl_with_code_block = \
"""
Voici du code
<%
print "3+4 font", 3+4
%>
cool non ?
"""

    parser = Pleet( tpl_with_code_block )
    print parser.render()

