"""A template system

Pleet is an extremely fast and easy to use template system. 
"""

import sys

classifiers = """\
Development Status :: 1 - Alpha
Intended Audience :: Developers
License :: OSI Approved :: GPL
Programming Language :: Python
Topic :: Templating
Topic :: Software Development :: Libraries :: Python Modules
Operating System :: Unix
"""

from distutils.core import setup

if sys.version_info < (2, 4):
    _setup = setup
    def setup(**kwargs):
        if kwargs.has_key("classifiers"):
            del kwargs["classifiers"]
        _setup(**kwargs)

doclines = __doc__.split("\n")

from distutils.core import setup

setup(name="pleet",
      version="devel",
      author="Nicolas Clairon",
      maintainer="Nicolas Clairon",
      maintainer_email="pleet-dev@gmail.com",
      url = "http://w3b.info-ufr.univ-montp2.fr/projets/pleet",
      license = "http://www.fsf.org/copyleft/gpl.html",
      platforms = ["any"],
      description = doclines[0],
      classifiers = filter(None, classifiers.split("\n")),
      long_description = "\n".join(doclines[2:]),
      packages=['pleet', "pleet/parser"]
      )

